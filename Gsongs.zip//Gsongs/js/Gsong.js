   // drope down buttion ----- --------------------------
//    document.getElementById("add_post").onclick = function () { myFunction() };
//    function myFunction() {
//        document.getElementById("add_post01").classList.toggle("add_post_sow");
//    };  
   document.getElementById("login-click").onclick = function () { myFunction() };
   function myFunction() {
       document.getElementById("log-click").classList.toggle("login_click_apter_sow");
   };  







document.getElementById("top-s01").onclick = function () { clicktopsongs()};

   function clicktopsongs(){
      document.getElementById("hidd-li-slo-10").classList.toggle("t-l-n-to-block");
   };
   